#!/bin/bash
ls -la | egrep -v ^d >> Q3temp 
awk '{if($1 != "total"){print $1, $9}else{print $0}}' Q3temp >> FINALinstruction
