#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main() {
  char dir1[100];
  char dir2[100];
  char dir3[100];
  char dir4[100];
  char dir5[100];
	
  strcpy(dir1,"mkdir FINALc");
  system(dir1);	
  strcpy(dir2,"mkdir -p /home/cli17/Test2/FINALc/copies");
  system(dir2);
  strcpy(dir3,"mkdir -p /home/cli17/Test2/FINALc/encrypted");
  system(dir3);
  strcpy(dir4,"mkdir -p /home/cli17/Test2/FINALc/decrypted");
  system(dir4);
  strcpy(dir5,"cp Q2.c FINALc");
  system(dir5); 
  return 0;
}
