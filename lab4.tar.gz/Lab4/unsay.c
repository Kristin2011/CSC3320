#include <stdio.h>
#include <string.h>
int main(){
char Input[30];
printf("Enter a number less than 100 in low case: ");
scanf("%s", Input);
    int length = strlen(Input);
    int i, symbol, temp, n1, n2, sum =0;
    for(i = 0; i < length;i++){
        if(Input[i]=='-'){
            symbol = i;
            break;
        }else{
	symbol = -1;
        }
    }if(symbol == -1){
        temp = Number(Input);
        printf("%d",temp);
    }else if(symbol != -1){
    int i = 0;
    char *sep = strtok(Input,"-");
    char *array[2];
        while(sep !=NULL){
            array[i]=sep;
            sep = strtok(NULL,"-");
            i++;    
        }
	n1 = Number(array[1]);
        n2 = Number(array[0]);
        sum = n1 + n2;
        printf("%d",sum);
     }
      printf("\n");
      return 0;
}

int  Number(char *n){
    int digital;   
    if(strcmp(n,"zero") == 0){
        digital = 0;
    }if(strcmp(n,"one") == 0){
        digital = 1;
    }if(strcmp(n,"two") == 0){
        digital = 2;
    }if(strcmp(n,"three") == 0){
	digital = 3;	
    }if(strcmp(n,"four") == 0){
        digital = 4;
    }if(strcmp(n,"five") == 0){
        digital = 5;
    }if(strcmp(n,"six") == 0){
        digital = 6;
    }if(strcmp(n,"seven") == 0){
	digital = 7;
    }if(strcmp(n,"eight") == 0){
        digital =8;
    }if(strcmp(n,"nine") == 0){
        digital =9;
    }if(strcmp(n,"ten") == 0){
        digital =10;
    }if(strcmp(n,"eleven") == 0){
        digital = 11;
    }if(strcmp(n,"twelve") == 0){
        digital = 12;
    }if(strcmp(n,"thirteen") == 0){
        digital = 13;
    }if(strcmp(n,"fourteen") == 0){
        digital = 14;
    }if(strcmp(n,"fifteen") == 0){
        digital = 15;
    }if(strcmp(n,"sixteen") == 0){
        digital = 16;
    }if(strcmp(n,"seventeen") == 0){
        digital = 17;
    }if(strcmp(n,"eighteen") == 0){
        digital = 18;
    }if(strcmp(n,"nineteen") == 0){
        digital = 19;
    }if(strcmp(n,"twenty") == 0){
        digital = 20;
    }if(strcmp(n,"thirty") == 0){
        digital = 30;
    }if(strcmp(n,"forty") == 0){
        digital = 40;
    }if(strcmp(n,"fifty") == 0){
        digital = 50;
    }if(strcmp(n,"sixty") == 0){
        digital = 60;
    }if(strcmp(n,"seventy") == 0){
        digital = 70;
    }if(strcmp(n,"eighty") == 0){
        digital = 80;
    }if(strcmp(n,"ninty") == 0){
	digital = 90;
    }return digital;
}
