#include<stdio.h>
#include<string.h>
int  Num(char *n){
    int digital;
    if(strcmp(n,"zero") == 0){
        digital = 0;
    }if(strcmp(n,"one") == 0){
        digital = 1;
    }if(strcmp(n,"two") == 0){
        digital = 2;
    }if(strcmp(n,"three") == 0){
        digital = 3;
    }if(strcmp(n,"four") == 0){
        digital = 4;
    }if(strcmp(n,"five") == 0){
        digital = 5;
    }if(strcmp(n,"six") == 0){
        digital = 6;
    }if(strcmp(n,"seven") == 0){
        digital = 7;
    }if(strcmp(n,"eight") == 0){
        digital =8;
    }if(strcmp(n,"nine") == 0){
        digital =9;
    }if(strcmp(n,"ten") == 0){
        digital =10;
    }if(strcmp(n,"eleven") == 0){
        digital = 11;
    }if(strcmp(n,"twelve") == 0){
        digital = 12;
    }if(strcmp(n,"thirteen") == 0){
        digital = 13;
    }if(strcmp(n,"fourteen") == 0){
        digital = 14;
    }if(strcmp(n,"fifteen") == 0){
        digital = 15;
    }if(strcmp(n,"sixteen") == 0){
        digital = 16;
    }if(strcmp(n,"seventeen") == 0){
        digital = 17;
    }if(strcmp(n,"eighteen") == 0){
        digital = 18;
    }if(strcmp(n,"nineteen") == 0){
        digital = 19;
    }if(strcmp(n,"twenty") == 0){
        digital = 20;
    }if(strcmp(n,"thirty") == 0){
        digital = 30;
    }if(strcmp(n,"forty") == 0){
        digital = 40;
    }if(strcmp(n,"fifty") == 0){
        digital = 50;
    }if(strcmp(n,"sixty") == 0){
        digital = 60;
    }if(strcmp(n,"seventy") == 0){
        digital = 70;
    }if(strcmp(n,"eighty") == 0){
        digital = 80;
    }if(strcmp(n,"ninty") == 0){
        digital = 90;
    }return digital;
}
int main (){
char string[50];
printf("Enter 2 number in lowcase below 100 to be multiply: ");
fgets(string,50,stdin);
strtok(string,"\n");

int i,j,k,l,m,word1, word2,symbol1,symbol2 = 0;
char *sep = strtok(string," ");
char *array[50];

while(sep !=NULL){
    array[i] = sep + '\0';
    sep = strtok(NULL," ");
    i++;
}
char *n1 = array[0];
char *n2 = array[1];

int length1 = strlen(n1);
int length2 = strlen(n2);
for(j = 0; j < length1; j++){
    if(n1[j]=='-'){
    symbol1 = j;
    break;
    }else{
    symbol1 = -1;
}}
    if(symbol1 == -1){
    word1 = Num(n1);
    }else if(symbol1 != -1){
    char *Sp1 = strtok(n1,"-");
    char *array1[2];
	while(Sp1 !=NULL){
            array1[k]=Sp1;
            Sp1 = strtok(NULL,"-");
       k++;
    }

int ten1 = Num(array1[0]);
int one1 = Num(array1[1]);
word1 = ten1 + one1;
}

for(l = 0; l < length2; l++){
    if(n2[l]=='-'){
        symbol2 = l;
        break;
     }else{
     symbol2 = -1;
     }
}
if(symbol2 == -1){
    word2 = Num(n2);
    }else if(symbol2 != -1){
    char *Sp2 = strtok(n2,"-");
    char *array2[2];
        while(Sp2 !=NULL){
            array2[m]=Sp2;
            Sp2 = strtok(NULL,"-");
            m++;
        }
    int tens = Num(array2[0]);
    int one2 = Num(array2[1]);
    word2 = tens + one2;
    }
    int mutl = word1 *word2;

printf("%d", word1);
printf(" * %d", word2);
printf(" = %d",mutl);
printf("\n");
return 0;
}



