#include<stdio.h>
int main(){
char userInput [50];
printf("Enter a string: ");
scanf("%s", userInput);
int number = atoi(userInput);
printf("you entered %d is an integer.\n", number);
return 0;
}


