#include<stdio.h>
#include<string.h>

int main(){
char Input[3];
printf("Enter a number less than 100: ");
scanf("%s",Input);
int length = strlen(Input);
        
if(length == 1){
char n1 = Input[0];
    conv(n1);
}
if(length == 2){
char n1 = Input[1];
char n2 = Input[0];
    if(n2=='1'){
        if(n1=='0'){
           printf("Ten");
       }if(n1=='1'){
	   printf("Eleven");
       }if(n1=='2'){
           printf("Twelve");
       }if(n1=='3'){
           printf("Thirteen");
       }if(n1=='4'){
           printf("Fourteen");
       }if(n1=='5'){
           printf("Fifteen");
       }if(n1=='6'){
           printf("Sixteen");
       }if(n1=='7'){
           printf("Seventeen");
       }if(n1=='8'){
           printf("Eighteen");
       }if(n1=='9'){
           printf("Nineteen");
       }printf("\n");
}
if(n2 =='2'){
    if(n1 =='0'){
	printf("Twenty\n");
    }else{
	printf("Twenty ");
	conv(n1);
}}if(n2 =='3'){
    if(n1 =='0'){
        printf("Thirty\n");
    }else{printf("Thirty ");
        conv(n1);
}}if(n2 =='4'){
    if(n1 =='0'){
        printf("Forty\n");
    }else{printf("Forty ");
        conv(n1);
}}if(n2 =='5'){
    if(n1 =='0'){
        printf("Fifty\n");
    }else{printf("Fifty ");
        conv(n1);
}}if(n2 =='6'){
    if(n1 =='0'){
        printf("Sixty\n");
    }else{printf("Sixty ");
        conv(n1);
}}if(n2 =='7'){
    if(n1 =='0'){
        printf("Seventy\n");
    }else{printf("Seventy ");
        conv(n1);
}}if(n2 =='8'){
    if(n1 =='0'){
        printf("Eighty\n");
    }else{printf("Eighty ");
        conv(n1);
}}if(n2 =='9'){
    if(n1 =='0'){
        printf("Ninty\n");
    }else{printf("Ninty ");
        conv(n1);
}}}if(length > 2){
printf("Number is above 100\n");
}
return 0;
}

void conv(char i){
    if(i == '0'){
	printf("zero");
    }if(i == '1'){
        printf("one");
    }if(i == '2'){
        printf("two");
    }if(i == '3'){
        printf("three");
    }if(i == '4'){
        printf("four");
    }if(i == '5'){
        printf("five");
    }if(i == '6'){
        printf("six");
    }if(i == '7'){
        printf("seven");
    }if(i == '8'){
        printf("eight");
    }if(i == '9'){
        printf("nine");
    }printf("\n");
return 0;
}      
