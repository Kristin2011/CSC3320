#include<stdio.h>
int main(){
int max,max2, product, i, j= 0;
    for (i = 0; i < 100; i++) {
        for (j = 0; j < 100; j++) {
            int temp = 0;
            product = i * j;
            int temp2 = product;
                while (product > 0) {
                  int remain = product % 10;
                  temp = (temp * 10) + remain;
                  product = product / 10;
                }if(temp2 == temp){
                    if(temp2 > max){
                        max = temp2;                    
}}}}       
    for (i = 0; i < 1000; i++) {
        for (j = 0; j < 1000; j++) {
            int temp = 0;
            product = i * j;
            int temp2 = product;
                while (product > 0) {
                  int remain = product % 10;
                  temp = (temp * 10) + remain;
                  product = product / 10;
                }if(temp2 == temp){
                    if(temp2 > max2){
                        max2 = temp2;
}}}}
printf("Max Palindorme for 2 digits number: %d\n",max2);
printf("Max Palindorme for 3 digits number: %d\n",max2);
return 0;
}
