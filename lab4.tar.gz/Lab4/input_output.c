#include<stdio.h>
int main(){
char userInput[50];
printf("Enter a string: ");
scanf("%[^\n]%*c", userInput);
printf("You entered: %s \n", userInput);
return 0;
}

