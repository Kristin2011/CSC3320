1st. I need to creat a .txt file to put all the number in there.
2nd. I create a string2Knuts.awk, by using substr and separe string by with /. and run the test, if there is error, went back to edit and continue test until it works.
3nd create a knuts2string.awk and using % and / to find the whole number and a remind number. 

4 creat a sum.awk and sum all the number.

*Every time when I create a new .awk, I have to use chmod +x <filename>  to change file mode.
./ script <filename> to run.
