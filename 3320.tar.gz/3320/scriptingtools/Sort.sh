#!bin/bash/
sort -k11 "$*" | grep "ATOM" 
