#!/bin/bash/
grep -v 'ATOM\|CONECT\|HETATM\|TER\|END' "$*" | awk '{print $1}'| sort -u

