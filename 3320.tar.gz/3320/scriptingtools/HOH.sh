#!bin/bash
sed 's/HOH/WAT/g' "$*" 
