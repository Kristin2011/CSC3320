1. copy the 4HKD.pdb from cumoja1/3320
2. create a Header.sh and use grep -v to exclude on the phrase and use awk to print only the header
3. create a AtomMet.awk and use {gsub("",""); print} to change "HETATM" to "ATOM  "and "MSE" to "MET"
4.creat a MinMax.awk and set a min and max for x, y,z. and all the "ATOM" search for x,y,z min and max. print all min and max.
5. creat a Mean.awk and count the number of x,y,z , and sum all x, sum all y, sum all z. and use sum/ count to find mean/
6. creat HOH.sh use sed to change "HOH" to "WAT"

* I need to use chmod +x <filename> to change all file type before excute.

