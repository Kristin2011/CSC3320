#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include <string.h>

int main(int argc, char **argv){
  DIR* fileDir;
  struct dirent* text;
  FILE    *start;
  FILE    *base;
  char    buffer[BUFSIZ];
  int key = 150;
  int letter;

  fileDir = opendir("/home/cli17/Test2/FINALc/copies"); 
  while ((text = readdir(fileDir))) {
    if (!strcmp (text->d_name, "."))
      continue;
    if (!strcmp (text->d_name, "..")) 
      continue;
    start = fopen(text->d_name, "r");    
    char s1[100] = ("/home/cli17/Test2/FINALc/encrypted/");
    char s2[50];
    strcpy(s2,text->d_name);
      strcat(s1,s2);
      base = fopen(s1, "w");
    while((letter = fgetc(start))!=EOF) {
      letter += key;
      if ((key - 1) > 0){
        key = (key - 1) % 256;
      }else{
        key= 255;
      }     
      fputc(letter,base);
    }
   fclose(start);
    fclose(base);
  }
  closedir(fileDir);
  return 0;
}
