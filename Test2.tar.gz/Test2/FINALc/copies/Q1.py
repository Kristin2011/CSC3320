from os import system
system("mkdir FINALpython")
system("cp Q1.py FINALpython")
system("mkdir -p /home/cli17/Test2/FINALpython/copies")
system("mkdir -p /home/cli17/Test2/FINALpython/encrypted")
system("mkdir -p /home/cli17/Test2/FINALpython/decrypted")
print("Sucessful create and copy.")
