from os import system

system("awk '{if($1 != 'total' ){print $2}}' FINALinstruction >> copyFiles")
system("xargs -a copyFiles cp -t /home/cli17/Test2/FINALpython/copies")
system("xargs -a copyFiles cp -t /home/cli17/Test2/FINALc/copies")

