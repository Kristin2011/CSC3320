import os

def encrypt(letter):
  key = 150
  result = ""
  for i in range(len(letter)):
    char = letter[i]
    result += chr((ord(char) - key)%256)
    if key - 1 > 0:
      key = (key -1) % 256
    else:
      key =255
  return result

for fileName in os.listdir(os.getcwd()):
  with open(os.path.join(os.getcwd(),fileName),"rb")as f:
    encFile = f.read()
    oldFile = encrypt(encFile)
    newFile = open("/home/cli17/Test2/FINALpython/decrypted/"+fileName,"wb")
    newFile.write(oldFile)
    newFile.close()
