import os

def encrypt(letter):
  key = 150
  secert = ""
  for i in range(len(letter)):
    character = letter[i]
    secert += chr((ord(character) + key)%256)
    if key - 1 > 0:
      key = (key -1) % 256
    else:
      key =255
  return secert


for filename in os.listdir(os.getcwd()):
  with open(os.path.join(os.getcwd(),filename),"rb")as f:
    text = f.read()
    encryptFile = encrypt(text)
    binaryFile = open("/home/cli17/Test2/FINALpython/encrypted/"+filename,"wb")
    binaryFile.write(encryptFile)
    binaryFile.close()

