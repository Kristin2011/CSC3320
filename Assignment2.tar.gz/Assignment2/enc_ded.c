#include<stdio.h>
#include<stdlib.h>
int main(int num, char *param[]){

if(num ==3){
int max1, max2,temp, i, aChar;
FILE *start;
FILE *after;
after = fopen (param[2],"w");

for(i = 1 ; i < 26 ; i++){
    int t = 0;
    int e = 0;
    int aChar;
    start = fopen (param[1],"r");
    while ((aChar = fgetc(start)) != EOF) {
        int letter = aChar;
        if( letter >= 'A' && letter <='Z'){
        letter += 32;
        }if(letter >= 'a' && letter <= 'z'){
        letter -= i;
        if(letter < 97){
        letter += 26;
        }if("%c",letter == 't'){
            t++;
        }if("%c",letter == 'e'){
            e++;
                }
        }
}
    if(e > max1){
        max1 = e;
        if(t > max2){
        max2 = t;
        temp = i;
                }
         }
 }
    int key = temp;
    start = fopen (param[1],"r");
    while ((aChar = fgetc(start)) != EOF) {
        int letter = aChar;
        if( letter >= 'A' && letter<='Z'){
        letter += 32;
        }if(letter >= 'a' && letter <= 'z'){
        letter = letter - key;
            if(letter < 97){
                letter += 26;
            }fprintf(after, "%c",letter);
            }else{
            fprintf(after, "%c",aChar);
            }
    }
}

if(num == 4){
FILE *startFile;
FILE *endFile;

startFile = fopen (param[1],"r");
endFile = fopen (param[2],"w");
int key = atoi(param[3]);
int aChar;

while((aChar = fgetc(startFile)) != EOF) {
    int letter = aChar;
    if(letter >= 'A' && letter<='Z'){
        letter += 32;
    }if(letter >= 'a' && letter <= 'z'){
        letter = 97 + (letter + key - 97) % 26;
        fprintf(endFile, "%c",letter);
    }else{
       fprintf(endFile, "%c",(char)aChar);
    }
}
close(startFile);
close(endFile);
}
return 0;
}
