#include<stdio.h>
#include<stdlib.h>
int main(int num, char *param[]){
FILE *startFile;
FILE *endFile;

startFile = fopen (param[1],"r");
endFile = fopen (param[2],"w");
int key = atoi(param[3]);
int aChar;

while((aChar = fgetc(startFile)) != EOF) {
    int letter = aChar;
    if(letter >= 'A' && letter<='Z'){
        letter += 32;
    }if(letter >= 'a' && letter <= 'z'){
        letter = 97 + (letter + key - 97) % 26;
        fprintf(endFile, "%c",letter);
    }else{
       fprintf(endFile, "%c",(char)aChar);
    }
}
close(startFile);
close(endFile);
return 0;
}
