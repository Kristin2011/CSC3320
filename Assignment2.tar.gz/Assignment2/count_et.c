#include<stdio.h>
#include<stdlib.h>

int main(int number, char *param[]){

int max1, max2,temp, i, aChar;
FILE *start;
FILE *after;
after = fopen (param[2],"w");
        
for(i = 1 ; i < 26 ; i++){
    int t = 0;
    int e = 0;
    int aChar;
    start = fopen (param[1],"r");
    while ((aChar = fgetc(start)) != EOF) {
        int letter = aChar;
        if( letter >= 'A' && letter <='Z'){
        letter += 32;
        }if(letter >= 'a' && letter <= 'z'){
    	letter -= i;
    	if(letter < 97){
   	letter += 26;
        }if("%c",letter == 't'){
            t++;
        }if("%c",letter == 'e'){
            e++;
 }  }   }
    if(e > max1){
        max1 = e;
        if(t > max2){
        max2 = t;
        temp = i;
}    }  }

    int key = temp;
    start = fopen (param[1],"r");
    while ((aChar = fgetc(start)) != EOF) {
        int letter = aChar;
        if( letter >= 'A' && letter<='Z'){
        letter += 32;
        }if(letter >= 'a' && letter <= 'z'){
        letter = letter - key;
            if(letter < 97){
                letter += 26;
            }fprintf(after, "%c",letter);
            }else{
            fprintf(after, "%c",aChar);
            }
    }
printf("Number of t: %d", max2);
printf("; Number of e: %d", max1);
printf("; Key: %d\n",key);
return 0;
}


