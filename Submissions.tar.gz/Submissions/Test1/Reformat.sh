#!/bin/bash
tr '\n' ' ' < "$*" | sed 's/)", /)" /g' |sed 's/)",, /)" /g' |sed 's/)" /)"\n /g' | sed 's/, -/. -/g'  |column -s, -t |less -S
