#!/bin/bash/
grep "$1" 2.asr | grep "$2" | grep -v "$3" 
