1st: I went to cd /home/cuojal/3320 copy over The Hunger Games.txt to my new directory.
2nd: I change The Hunger Games.txt to My Hunger Games.txt
3rd. Replace all the Effie to Chaoqun
