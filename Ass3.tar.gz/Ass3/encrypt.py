import sys

inputData = open("message1.txt").read()
file = open("encrypt.txt", "w")

key = input('Enter a number: ')

result = ""
for i in inputData:
  i.lower()
  if(ord(i)>= ord('a') and ord(i)<= ord('z')):
    result = chr(97 + (ord(i) + key -97 ) % 26)
    file.write(result)
  else:
    file.write(i)

file.close()

