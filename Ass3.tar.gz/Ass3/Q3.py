User =raw_input("Enter encrypt or decode: ")

if(User == 'decode'):

  import sys

  inputData = open("ceaser2.txt").read()
  file = open("Q3decoded.txt", "w")

  inputData.lower()
  List = [0] * 26

  for i in inputData:
    if (i.isalpha() == True):
      List[ord(i)-ord('a')] += 1

  maxA= max(List)
  maxC= List.index(maxA)

  for i in range(0, 26, 1):
    print('Letter {} appear {} times'.format(chr(i+ord('a')), List[i]))

  print("Most common letter : " + chr(maxC + ord('a')))

  findK = abs(ord('e') - (maxC +ord('a')))

  print('Key: ' +str(findK))

  for i in inputData:
    if(ord(i)>= ord('a') and ord(i)<= ord('z')):
      result =ord(i) - findK;
      if (result < 97):
        result  = result + 26
      file.write(chr(result))
    else:
      file.write(i)

  file.close()

elif(User == 'encrypt'):

  import sys

  inputData = open("ceaser2.txt").read()
  file = open("Q3encrypt.txt", "w")

  key = input('Enter a number: ')

  result = ""
  for i in inputData:
    i.lower()
    if(ord(i)>= ord('a') and ord(i)<= ord('z')):
      result = chr(97 + (ord(i) + key -97 ) % 26)
      file.write(result)
    else:
      file.write(i)

  file.close()
