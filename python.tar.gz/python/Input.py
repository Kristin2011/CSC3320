enter = raw_input("Enter a string: ")
print(enter)


