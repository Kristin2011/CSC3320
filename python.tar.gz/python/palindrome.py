def Palindrome(n): 
  temp = 0
  for i in range(1, n+1): 
    temp = temp * 10
    temp = temp + 9  
    temp2 = 1 + temp//10
    maxNum = 0 
    
  for i in range(temp, temp2-1, -1):     
    for j in range(i, temp2-1, -1): 
      mutl = i * j 
      if (mutl < maxNum): 
        break
      number = mutl 
      reverse = 0
   
      while (number != 0): 
        reverse = reverse * 10 + number % 10
        number =number // 10
        
      if (mutl == reverse and mutl > maxNum): 
         maxNum = mutl   
 
  return maxNum 

n = 2
x = 3
print("Large palindrome for 2 digits number: ")
print(Palindrome(n)) 
print("Large palindrome for 3 digits number: ")
print(Palindrome(x)) 
