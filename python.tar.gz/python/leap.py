year = int(raw_input("Enter a random year: "))
if (( year % 4 == 0)or (( year % 400 == 0 ) and ( year % 100 != 0))):
    print("%d is a Leap Year." % year)
else:
    print("%d is not the Leap Year." % year)
