oneD=['zero','one','two','three','four','five','six','seven','eight','nine']
twoD=['eleven','twelve','thirteen','fourteen','fifteen','sixteen',
'seventeen','eighteen','nineteen']
ten=['ten','twenty','thirty','forty','fifty','sixty','seventy','eighty',
'ninety','one hundred']

def find(str):
  try:
    temp=oneD.index(str)
  except:
    try:
      temp=twoD.index(str)+11
    except:
      temp=ten.index(str)+1
      temp=temp*10
  return temp;

num1=raw_input('Enter a number below 100 in lowercase: ')
num2=raw_input('Enter another number below 100 in lowercase: ')
num1=num1.split('-')
n1 = len(num1)
if(n1==1):
  num1=find(num1[0])
else:
  temp1=find(num1[0])
  temp2=find(num1[1])
  num1 = temp1 + temp2

num2=num2.split('-')
n2 = len(num2)
if(n2==1):
  num2=find(num2[0])
else:
  temp3=find(num2[0])
  temp4=find(num2[1])
  num2 = temp3 + temp4

total = num1 * num2
print num1, '*', num2, '=' , total 


