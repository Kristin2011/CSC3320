String = raw_input("Enter a number: ")
print(String)
print(type(String))
num = int(String)
print("String to number:")
print(num)
print(type(num)) 
             
