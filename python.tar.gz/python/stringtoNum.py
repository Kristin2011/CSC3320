oneD=['zero','one','two','three','four','five','six','seven','eight','nine']
twoD=['eleven','twelve','thirteen','fourteen','fifteen','sixteen',
'seventeen','eighteen','nineteen']
ten=['ten','twenty','thirty','forty','fifty','sixty','seventy','eighty',
'ninety']

def find(str):
  try:
    temp=oneD.index(str)
  except:
    try:
      temp=twoD.index(str)+11
    except:
      temp=ten.index(str)+1
      temp=temp*10
  return temp;

number=raw_input('Enter a number below 100 in lowercase(EX: ninety-nine): ')
number=number.split('-')
#print(number)
n = len(number)
if(n==1):
  num1=find(number[0])
  print(num1)
else:
  num1=find(number[0])
  num2=find(number[1])
  print(num1+num2) 
