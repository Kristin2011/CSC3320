oneD=['zero','one','two','three','four','five','six','seven','eight','nine']
twoD=['eleven','twelve','thirteen','fourteen','fifteen','sixteen',
'seventeen','eighteen','nineteen']
ten=['ten','twenty','thirty','forty','fifty','sixty','seventy','eighty',
'ninety','one hundred']

number=int(raw_input("Enter number: "))

if number < 10:
  print(oneD[number])
elif number%10==0:
  print(ten[int(number/10)-1])
elif number<20 and number>10:
  print(twoD[number%10-1])
else:
  print('%s %s' %(ten[int(number/10)-1],oneD[number%10]))
