import binascii
def dehexify(hexfilepath):
  data = open(hexfilepath, "r").read()
  unhex = binascii.unhexlify(data)
  print(unhex) 
dehexify("hex_dump") 
