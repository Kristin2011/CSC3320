import binascii
Input = raw_input("Enter a string:\n")
print("String to binary/n")
binary = binascii.a2b_base64(Input.strip())
print(binary)
print("Binary back to String:")
string = binascii.b2a_base64(binary)
print(string)
