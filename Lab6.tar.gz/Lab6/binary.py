from os import system
binary_data = open("/home/cli17/Lab6/data", "rb").read()
f = open("./copied_data", "wb")
f.write(binary_data)
f.close()
print("print out the binary file.")
system("chmod 777 copied_data; ./copied_data")
